// OG manifest       "js": ["scripts/email.min.js","scripts/content.js", "scripts/form.js"],
window.onload = function() {
    setTimeout(() => {
        const questions = document.querySelectorAll('div[data-automation-id="questionItem"] > div[class="-oK-217"]');
        const asks = document.querySelectorAll('div[data-automation-id="questionItem"] > div:nth-child(2) > div');
        const numQuestion = document.querySelectorAll('span[role="heading"] > span[data-automation-id="questionOrdinal"]');
        const textQuestion  = document.querySelectorAll('span[role="heading"] > span[class="text-format-content "]');


        let data=[];
        console.log("HTMLCollection length: ", numQuestion.length);  // Verifica si hay elementos
        if (numQuestion.length > 0) {
            for (let i = 0; i < numQuestion.length; i++) {
                let ask = asks[i].firstChild;
                console.log(numQuestion[i].innerText, textQuestion[i].innerText,ask);

                data.push(
                    {
                        "numQuestion" : numQuestion[i].innerText,
                        "textQuestion" : textQuestion[i].innerText,
                        // "questionId" : questions[i].id,
                        "ask" : null
                    });

                if (ask.classList.contains("--hF-227")) {
                    data[i].ask = ask.getAttribute("aria-label");
                } else if (ask.classList.contains("-oK-263")) {
                    let selectedChoices = ask.querySelectorAll('div.lrp-choice-selected'); 
                    if (selectedChoices.length > 0) {
                        data[i].ask = [];
                        selectedChoices.forEach(choice => {
                            let choiceText = choice.querySelector('div > label span.text-format-content');
                            if (choiceText) {
                                data[i].ask.push(choiceText.innerText); // Agrega el texto al arreglo
                            }
                        });
                    } else {
                        data[i].ask = "Vacio";
                    }
                } else if (ask.classList.contains("-XZ-237")) {
                    data[i].ask = ask.firstChild.value;
                } else {
                    data[i].ask = "No es un campo de texto o no tiene el id 'textInput'";
                }//el de escala la diferencia es una clase :'(
                
            }
            console.log(data);
        } else {
            console.log("No se encontraron elementos con la clase '-CO-222'.");
        }
    }, 10000); 
};
  


